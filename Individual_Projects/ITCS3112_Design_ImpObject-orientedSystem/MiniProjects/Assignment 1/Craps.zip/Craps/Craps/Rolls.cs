﻿using System;
namespace Craps
{
    /**
     * 
     * Class Name : Craps
     * Student Name: Andy Le
     * Date: May 20, 2020
     * Description: This class simulate two dicing by using built-in random method
     * 
     */
    public class Rolls
    {
        private Random rand;//hold the random number from 1 to 6
        private int Dice1;//hold the number after rolling of die 1
        private int Dice2;//hold the number after rolling of die 2

        /**
         * Mutual method for the fields
         */
        public int Die11 { get => Dice1; set => Dice1 = value; }
        public int Die21 { get => Dice2; set => Dice2 = value; }


        /**
         * Non-arguments contructor
         */
        public Rolls()
        {
            rand = new Random();
        }

        /**
         * This method return a sum of the faces of the two dice
         * @return A sum of the faces of the two dice
         */
        public int RollDice()
        {
            Dice1 = rand.Next(1, 7);
            Dice2 = rand.Next(1, 7);

            return Dice1 + Dice2;
        }
        
    }
}
