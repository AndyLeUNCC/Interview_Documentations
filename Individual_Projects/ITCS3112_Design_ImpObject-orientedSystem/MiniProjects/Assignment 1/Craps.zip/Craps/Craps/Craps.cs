﻿using System;

namespace Craps
{
    /**
     * 
     * Class Name : Craps
     * Student Name: Andy Le
     * Date: May 20, 2020
     * Description: This class simulate a gram of Craps.
     * 
     */
    class Craps
    {
        //Special number when the player play
        private enum DiceSum { SNAKE_EYES = 2, TREY = 3, SEVEN =7, YO_LEVEN = 11, BOX_CARS = 12}
        //Each game has three status
        private enum GameStatus { WIN, LOSE, PLAY_MORE}
        private Rolls rolls;//hold the roll state when dicing

        private GameStatus gameStatus;//hold the game status
        private int numRolls;//hold the number of rolling
        private int sum;//hold the sum of the faces of the two dice 
        private int point;//hold the point of the player each game

        //The player will be assigned 100 chips before begining to play the game.
        private int chips;
        private int chipsWager;//hold the number of chips if the player had a wager
        private ConsoleKeyInfo makeAWager;//hold "Y" if the player want to make a wager
        private ConsoleKeyInfo keepGoing;//hold "Y" if the player want to play another game

        /**
         * mutual method of fields
         */
        public int Sum { get => sum; set => sum = value; }
        public int Point { get => point; set => point = value; }
        public int ChipsWager { get => chipsWager; set => chipsWager = value; }
        public int Chips { get => chips; set => chips = value; }

        /**
         * non-argument constructor
         */
        public Craps()
        {
            rolls = new Rolls();
            gameStatus = GameStatus.PLAY_MORE;
            numRolls = 1;
            chips = 100;
            chipsWager = 0;
        }

        /**
         * This method ask to make a wager each time the game is played
         */
        private void askMakeAWager()
        {
            

            Console.WriteLine("Press 'y' if you would like to make a wager!");
            Console.Write("Would you like to make a wager?(Y/N)");
          
            makeAWager = Console.ReadKey();
            Console.WriteLine();
            if (makeAWager.Key.ToString().ToLower() == "y")
            {
                int resultParseNumber = -1;//hold the result of parse string input for check a number or not
                do
                {
                    Console.WriteLine("Please enter number of chips greater than 0 for a wager.");
                    Console.Write("How many chips would you like to make a wager:");
                    string strInput = Console.ReadLine();
                    resultParseNumber = validateChipsWager(strInput);
                    if (resultParseNumber != -1)
                    {
                        chipsWager = resultParseNumber;
                    }
                    else
                    {
                        Console.WriteLine("Your input {0} is not a Number greater than 0. Please input again a number for a wager!", strInput);
                    }
                    Console.WriteLine();

                } while (resultParseNumber == -1);
                

            }
            
            

            
        }
        /**
         * This method check a string input is a positive number or not.
         * If the input is a number and greater than 0, then return a valid number.
         * Otherwise, return -1.
         * 
         * @para A string input 
         * @return A valid number
         */
        private int validateChipsWager(string strInput)
        {
            int result = 0;
            if (int.TryParse(strInput, out result))
            {
                if (result > 0) return result;
                else return -1;
         
            } else
            {
                return -1;
            }
        }

        /**
         * This method will evaluate the chips base on a wager that the player make or not
         * if the player had a wager the chips will be double if the player won game.
         * Otherwise, the chips will be lost.
         */
        private void evaluateWager()
        {
            switch (gameStatus)
            {
                case GameStatus.WIN:

                    if (makeAWager.Key.ToString().ToLower() == "y")
                    {
                        Chips = Chips - ChipsWager;
                        ChipsWager = 2 * ChipsWager;
                        Chips = Chips + ChipsWager;
                    }
                    
                    break;
                case GameStatus.LOSE:
                    if (makeAWager.Key.ToString().ToLower() == "y")
                    {
                        Chips = Chips - ChipsWager;
                    }
                    
                    break;
                default:
                   
                    break;
            }
            
        }
        /**
         * This method show the instruction of game.
         */
        private void showInstructionOfGame()
        {
            Console.WriteLine("The player will be assigned 100 chips before beginning to play the game.");
            Console.WriteLine("Each time the game is played, the user will be asked to make a wager.");
            Console.WriteLine("If you wins the game, you receive double chips if you make a wager.");

        }
        /**
         * This method simulte a game dicing
         */
        public void playGame()
        {
            showInstructionOfGame();
            do
            {
                
                /**
                 *ask the player make a wager
                 */
                askMakeAWager();
                while (gameStatus == GameStatus.PLAY_MORE && Chips > 0)
                {
                    Sum = rolls.RollDice();

                    evaluateSumDiceTheFirstThrow();
                    evaluateWager();
                    showMessage();
                    /**
                     * To win, he must keep throwing the dice until he "makes his point",
                     * that is the sum of the dice is equal to his point.
                     * The player loses if he throws a 7 before making his point.
                     */
                    while (gameStatus == GameStatus.PLAY_MORE && Chips > 0)
                    {
                        keepPlaying();
                        evaluateWager();
                        numRolls++;
                        showMessage();
                    }
                }
                //Todo for test
                //Console.WriteLine("The total number of chips remaining is {0}.", Chips);
                if (Chips == 0)
                {
                    //if the remaing chips is 0 then the player can not play another game
                    break;
                }
                /**
                 * When a game is finished, the program should ask if the player wants to play another.
                 * It should either play another game or terminate, based on the user response. 
                 */
                Console.WriteLine("Would you like to play another?(Y/N)");
                Console.Write("Press 'y' if you would like make another game!");

                keepGoing = Console.ReadKey();
                Console.WriteLine();

                //reset game status for another game if the player want to play
                gameStatus = GameStatus.PLAY_MORE;
                


            } while (keepGoing.Key.ToString().ToLower() == "y" && Chips > 0);
            
            /**
             * When the player does not wish to play anymore or all the chips are used,
             * display the number of chips remaining. 
             */
            Console.WriteLine("The total number of chips remaining is {0}.", Chips);

        }

        /**
         * This method will evaluate the sum of the faces of the 2 dice base on the rules
         * if the sum is 7 or 11 on the first throw, the player wins and the game is over.
         * if the sum is 2,3, or 12 on the first throw, the play loses an the game is over.
         * if the sum is 4, 5,6,8,9 or 10 on the first throw, then that sum is known as the player's "point"
         * 
         */
        private void evaluateSumDiceTheFirstThrow()
        {
            switch ((DiceSum)Sum)
            {
                case DiceSum.SEVEN:
                case DiceSum.YO_LEVEN:
                    gameStatus = GameStatus.WIN;
                    Point = 0;
                    break;
                case DiceSum.SNAKE_EYES:
                case DiceSum.TREY:
                case DiceSum.BOX_CARS:
                    gameStatus = GameStatus.LOSE;
                    Point = 0;
                    break;
                default:
                    /**
                     * if the sum is 4, 5,6,8,9 or 10 on the first throw,
                     * then that sum is known as the player's "point"
                     */
                    gameStatus = GameStatus.PLAY_MORE;
                    Point = Sum;
                    break;

            }
        }
        
        /**
        * This method keep throwing the dice until he "makes his point",
        * that is the sum of the dice is equal to his point.
        * The player loses if he throws a 7 before making his point.
        */
        private void keepPlaying()
        {
            Sum = rolls.RollDice();
            if (Sum == Point)
            {
                gameStatus = GameStatus.WIN;
            }
            else if ((DiceSum)Sum == DiceSum.SEVEN)
            {
                gameStatus = GameStatus.LOSE;
            }
            else
            {
                gameStatus = GameStatus.PLAY_MORE;
            }
        }

        /**
         * This method show the message to user to notice Win, Lose or Keep Rolling
         */
        private void showMessage()
        {
            switch (gameStatus)
            {
                case GameStatus.WIN:
                    
                    Console.WriteLine("You win this game! Congratulations, you rolled {0}.", Sum);
                    break;
                case GameStatus.LOSE:
                    Console.WriteLine("You lose this game! Sorry, you rolled {0}", Sum);
                    break;
                default:
                    if (numRolls == 1)
                        Console.WriteLine("Your point is {0}. You must keep rolling. ", Point);
                    else
                        Console.WriteLine("Your point is {0}. You rolled {1}. You must keep rolling.", Point,Sum);
                    break;
            }
        }


    }
}
