﻿using System;
namespace Craps
{
    /**
     * 
     * Class Name : DemoCraps
     * Student Name: Andy Le
     * Date: May 20, 2020
     * Description: This class excutes the program as a point start
     * 
     */
    public class DemoCraps
    {
       

        public static void Main(string[] args)
        {
            Console.Clear();
            Craps craps = new Craps();
            craps.playGame();
            Console.ReadLine();
        }
    }
}
