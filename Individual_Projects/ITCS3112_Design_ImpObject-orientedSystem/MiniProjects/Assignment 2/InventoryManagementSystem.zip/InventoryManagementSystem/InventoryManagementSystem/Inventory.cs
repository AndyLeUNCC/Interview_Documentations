﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace InventoryManagementSystem
{
    /**
     * 
     * Class Name : DemoCraps
     * Student Name: Andy Le
     * Date: May 30, 2020
     * Description: This class represent an inventory that includes all of warehouse and transaction item list
     * all of warehouse include six warehouses (Atlanta,Baltimore, Chicago, Denver, Ely and Fargo) and sells five different items
     * (identified by part number: 102, 215, 410, 525 and 711). 
     * Each warehouse may stock any or all of the five items. The company buys and sells these items constantly. 
     * Company transaction records contain a transaction code (‘P’ for a purchase or ‘S’ for a sale) followed by an item number and the quantity (bought or sold).
     * 
     * 
     */
    public class Inventory
    {
        List<WareHouse> wareHouseList;//store the list of warehouse
        List<TransactionItem> transactionItemList;//store the list of transaction item
        

        public List<WareHouse> WareHouseList { get => wareHouseList; set => wareHouseList = value; }
        public List<TransactionItem> TransactionItemList { get => transactionItemList; set => transactionItemList = value; }
        
        /**
         * non-argument constructor
         */
        public Inventory()
        {
            this.wareHouseList = new List<WareHouse>();
            

            this.transactionItemList = new List<TransactionItem>();
        }

        /**
         */
        public Inventory(List<WareHouse> wareHouseList)
        {
            this.wareHouseList = wareHouseList;
        }

        
        /**
         *   This method will search and update and return a warehouse that satified supply of the transaction item 
         *   For a sale ('S') - find out the warehouse that has the largest supply of the item on hand
         *   For a sale ('P') - find out the warehouse that has the lowest supply of the item on hand
         *   
         *   This method will also ouput a warehouse that has status before updated to reflect that transaction item
         *   
         */
        public WareHouse searchAndUpdateWareHouseSatifiedSupplyOfItem(TransactionItem givenItem, out WareHouse beforeUpdatedWareHouse)
        {

            List<KeyValuePair<string,int>> items = new List<KeyValuePair<string,int>>();

            
            /**
             * each warehouse in list of warehouse, get each item to compare with given item by identifiedNumber.
             * if there is item has same identifiedNumber then store the quantity of that item to List number to search max, min
             * with the List number, we can get the position of max, min to have the name of Warehouse    
             */
            
          
            items = createItemListHasWareHouseNameAndItemNumber(givenItem);

            int itemValue = 0;
            string itemKey = "";
            itemValue = items.First().Value;
            itemKey = items.First().Key;

            if (givenItem.TransactionCode == "P")
            {
                //determine the ware house that has lowest suuply of item                
                foreach (KeyValuePair<string, int> pair in items)
                {
                    if (itemValue > pair.Value)
                    {
                        itemKey = pair.Key;
                        itemValue = pair.Value;
                    }
                }
            } else if (givenItem.TransactionCode == "S")
            {
                //determine the ware house that has largest suuply of item
                foreach (KeyValuePair<string, int> pair in items)
                {
                    if (itemValue < pair.Value)
                    {
                        itemKey = pair.Key;
                        itemValue = pair.Value;
                    }
                }

            }

            /**
             * parse string that contains of warehouse name and identified numver of item
             * to get info of warehouse and item that satifies with search condition from given transaction item
             * For example:
             * parse string "Atlanta,102"  => warehouse name = Atlanta and item's identified number = 102
             */
            string keyWareHouseName = "";
            string keyItemIdentifiedNumber = "";

            keyWareHouseName = itemKey.Split(",").ToList()[0];
            keyItemIdentifiedNumber = itemKey.Split(",").ToList()[1];

            /**
             * Find the warehouse that contains name same with name of warehouse satified condition 
             */
            WareHouse wareHouseSatifiedCondition;
            wareHouseSatifiedCondition = wareHouseList.Find(wareHouse => keyWareHouseName == wareHouse.WareHouseName);

            beforeUpdatedWareHouse = new WareHouse(wareHouseSatifiedCondition);//save the before status of warehouse

            //update the warehouse that has the largest or lowest supply of that item on hand
            Item itemSupply = wareHouseSatifiedCondition.ItemList.Find(item => item.IdentifiedNumber == keyItemIdentifiedNumber);

            if (givenItem.TransactionCode == "P")
            {
                itemSupply.Quantity = itemSupply.Quantity + givenItem.Quantity;
            }
            else if (givenItem.TransactionCode == "S")
            {
                itemSupply.Quantity = itemSupply.Quantity - givenItem.Quantity;

            }
                
            Item updateItem = new Item(itemSupply);
            wareHouseSatifiedCondition.updateItemList(updateItem);

            //update warehouse list with new information of warehouse that was updated
            updateWareHouseList(wareHouseSatifiedCondition);

            return wareHouseSatifiedCondition;
        }

        /**
         * This method update an warehouse in warehouse list base on the given warehouse
         *   
         */
        private void updateWareHouseList(WareHouse givenWareHouse)
        {
            //search warehouse has same name with given warehouse
            int itemIndex = wareHouseList.FindIndex(wareHouse => givenWareHouse.WareHouseName == wareHouse.WareHouseName);
            var item = wareHouseList.ElementAt(itemIndex);
            item = givenWareHouse;
        }

        /**
         * This method create a item list that contains a pair of key and value.
         * key = warehouse name, identified number of item
         * value = quantity of item
         */
        private List<KeyValuePair<string, int>> createItemListHasWareHouseNameAndItemNumber(TransactionItem givenItem)
        {
            List<KeyValuePair<string, int>> items = new List<KeyValuePair<string, int>>();
            foreach (WareHouse wareHouse in wareHouseList)
            {
                List<Item> itemList = wareHouse.ItemList;
                foreach (Item item in itemList)
                {
                    if (item.IdentifiedNumber == givenItem.IdentifiedNumber)
                    {
                        items.Add(new KeyValuePair<string, int>(wareHouse.WareHouseName + "," + item.IdentifiedNumber, item.Quantity));
                    }
                }


            }

            return items;
        }

        /**
         * This method read the file Inventory.txt and store data into list of warehouse
         */
        public void readInventoryTxtFile(string fileName)
        {
            TxtFileUtility txtFile = new TxtFileUtility();
            List<String> inventory = txtFile.readTextFile(fileName);
            int wareHouseCode = 0;
            //store date into list of warehouse
            foreach(String data in inventory)
            {
                wareHouseCode++;
                List<string> record = txtFile.splitRecordIntoField(data);
                //parse record into a warehouse
                WareHouse wareHouse = new WareHouse();
                wareHouse = wareHouse.parseDataIntoWareHouse(wareHouseCode,record);

                //put itemList into a warehouse
                wareHouseList.Add(wareHouse);
            }

        }

        /**
         * This method read the file Transactions.txt and store data into list of transaction item
         *           List<TransactionItem> transactionItemList
         */
        public void readTransactionTxtFile(string fileName)
        {
            TxtFileUtility txtFile = new TxtFileUtility();
            List<String> transactionList = txtFile.readTextFile(fileName);
            //store date into list of transaction item
            foreach (String data in transactionList)
            {
                
                //parse record into a transaction item
                TransactionItem transactionItem = new TransactionItem();
                List<string> record = txtFile.splitRecordIntoField(data);
                transactionItem = transactionItem.parseDataIntoTransactionItem(record);

                //put transaction item into a transaction item list
                transactionItemList.Add(transactionItem);
            }


        }

        /**
         * This method will show all transactions that are read from Transactions.txt file
         */
        public String showAllTransaction()
        {
            string statusTransactionList = "";
            statusTransactionList += "\tTransaction Code" + "\tItem Number" + "\tQuantity\n";
            foreach (TransactionItem transactionItem in transactionItemList)
            {
                statusTransactionList += transactionItem;
            }

            return statusTransactionList;
        }
        /**
         * This method will return the status of all warehouses
         */
        public override string ToString()
        {
            String status = "";
            
            foreach (WareHouse wareHouse in wareHouseList)
            {
                status += wareHouse;
            }

            return status;
        }
    }
}