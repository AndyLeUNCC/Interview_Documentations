﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace InventoryManagementSystem
{
    /**
     * 
     * Class Name : DemoCraps
     * Student Name: Andy Le
     * Date: May 30, 2020
     * Description: This class represent a warehouse
     * 
     */
    public class WareHouse
    {

        //item order
        List<Item> itemList; //store the list of item (5 items)
        private string wareHouseName;//hold the warehouse name

        public string WareHouseName { get => wareHouseName; set => wareHouseName = value; }
        public List<Item> ItemList { get => itemList; set => itemList = value; }


        /**
         * non-argument constructor
         */
        public WareHouse()
        {
            this.itemList = new List<Item>();
            this.wareHouseName = "";
        }

        /**
         * using Copy contructor to avoid security hole
         */
        public WareHouse(List<Item> itemList, string wareHouseName)
        {
            this.itemList = new List<Item>();

            //need clone each item into new memory
            foreach (var item in itemList)
            {
                this.itemList.Add(new Item(item));
            }
            this.wareHouseName = wareHouseName;
        }


        /**
         * Copy contructor
         */
        public WareHouse(WareHouse wareHouse)
        {
            this.itemList = new List<Item>();

            foreach (var item in wareHouse.itemList)
            {
                this.itemList.Add(new Item(item));
            }
            wareHouseName = wareHouse.WareHouseName;
        }

        /**
         * This method update an item in item list base on the given item
         * 
         */
        public void updateItemList(Item givenItem)
        {
            //search item has same identified number with given item
            Item item = itemList.Find(item => item.IdentifiedNumber == givenItem.IdentifiedNumber);
            item.Quantity = givenItem.Quantity;
        }

        /**
         * This method parse data into a warehouse and return a warehouse object
         */
        public WareHouse parseDataIntoWareHouse(int wareHouseCode,List<string> record)
        {
            if (wareHouseCode == 1)
            {
                wareHouseName = "Atlanta";
            }
            else if (wareHouseCode == 2)
            {
                wareHouseName = "Baltimore";
            }
            else if (wareHouseCode == 3)
            {
                wareHouseName = "Chicago";
            }
            else if (wareHouseCode == 4)
            {
                wareHouseName = "Denver";
            }
            else if (wareHouseCode == 5)
            {
                wareHouseName = "Ely";
            }
            else if (wareHouseCode == 6)
            {
                wareHouseName = "Fargo";
            }

            
            Item item102 = new Item("102",record[0]);
            Item item215 = new Item("215",record[1]);
            Item item410 = new Item("410",record[2]);
            Item item525 = new Item("525",record[3]);
            Item item711 = new Item("711",record[4]);


            itemList.Add(item102);
            itemList.Add(item215);
            itemList.Add(item410);
            itemList.Add(item525);
            itemList.Add(item711);

            WareHouse wareHouse = new WareHouse(itemList, wareHouseName);


            return wareHouse;
        }

       

        /**
         * toString method to show the status of warehouse object
         */
        public override string ToString()
        {
            /**
            * Display the  status of a warehouse
            *   =====================================================
            *   The Atlanta warehouse
            *      Item     Quantity
            *      102       500
            *      215       120
            *      410       60
            *      525       0
            *      711       350
            *   
            *        
            */
            String status = "";
            status = "\nThe " + wareHouseName + " warehouse\n";
            status += "\tItem" + "\tQuantity\n";
            foreach(Item item in itemList)
            {
                status += "\t" + item.IdentifiedNumber + "\t" + item.Quantity + "\n";
            }

            return status;
        }
    }
}