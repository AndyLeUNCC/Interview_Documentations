﻿using System;

namespace InventoryManagementSystem
{
    /**
     * 
     * Class Name : Item
     * Student Name: Andy Le
     * Date: May 29, 2020
     * Description: This class represent an item of warehouse.
     * 
     */
    public class Item
    {
        
        private String identifiedNumber;// (102,215,410, 525, and 711)
        private int quantity;//hold the quantity 

        /**
         * non-argument constructor
         */
        public Item()
        {
            identifiedNumber = "";
            quantity = 0;
        }
        /**
         * argument constructor
         */
        public Item(Item item)
        {
            identifiedNumber = item.identifiedNumber;
            quantity = item.Quantity;
        }
        /**
         * argument constructor
         */
        public Item(string identifiedNumber, string quantity)
        {
            this.identifiedNumber = identifiedNumber;
            this.quantity = int.Parse(quantity);
        }

        public string IdentifiedNumber { get => identifiedNumber; set => identifiedNumber = value; }
        public int Quantity { get => quantity; set => quantity = value; }


    }
}