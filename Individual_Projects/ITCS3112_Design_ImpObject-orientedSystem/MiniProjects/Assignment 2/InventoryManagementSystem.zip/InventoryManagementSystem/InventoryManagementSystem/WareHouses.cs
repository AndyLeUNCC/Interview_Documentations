﻿using System;

namespace InventoryManagementSystem
{
    /**
     * 
     * Class Name : DemoCraps
     * Student Name: Andy Le
     * Date: May 30, 2020
     * Description: This class excutes the program as a point start
     * 
     */
    public class WareHouses
    {
        //constants to represent the menu options
        //const int RUN_ALL_STEP = 1;
        const int DISPLAY_INITIAL_STATUS_ALL_WAREHOUSES = 1;
        const int DISPLAY_LIST_TRANSACTION_FROM_TXT_FILE = 2;
        const int DISPLAY_FINAL_STATUS_ALL_WAREHOUSES = 3;
        const int EXIT_CHOICE = 4;

        static private Inventory inventory = new Inventory();//store the all warehouse
 
        /**
         * This a main point to start program
         */
        static void Main(string[] args)
        {
            int choice = 0;//to hold the menu choice        
            Console.Clear();
            do
            {
                choice = getOptionFromMenu();
                if (choice == EXIT_CHOICE)
                {
                    Console.WriteLine("Exit programm sucessfully!");
                    break;
                }

                //processing the option that user chose
                processUserOption(choice);

                
            } while (choice != EXIT_CHOICE); //we want to iterate again whenever the user enters number 5


        }

        /**
         * This method will run all step from the initial status of all warehouse to display the final status of all warehouse
         */
        public static void runAllStep()
        {
            displayTheInitialStatusAllWareHouse();
            displayTheTransactionsTextFile();
            processAllTransactionAndShowTheUpdatedWareHouse();
            displayTheFinalStatusAllWareHouse();
        }


        /**
        * Method: getOptionFromMenu
        * This method will show the options of menu to user.
        * 
        * @return The option choice of user
        * 
        */

        public static int getOptionFromMenu()
        {
            //Display the Menu
            Console.WriteLine("\n*******************************************************");
            Console.WriteLine("Inventory Management System Menu");
            //Console.WriteLine("\t1. Run all steps from display the initial to final status for all warehouses.");

            Console.WriteLine("\t1. Create and Display the initial (beginning of the day) status of all warehouse");
            Console.WriteLine("\t2. Process transaction file and show which warehouse's inventory was updated to reflect that transaction");
            Console.WriteLine("\t3. Display the final (end-of-day) status for all warehouses");
            Console.WriteLine("\t4. Exit");

            Console.WriteLine("\nPlease entering an option from the menu above");//Ask the user to make a selection from the menu
            int choice = readInt();//read in the user's input for the menu selection

            while (choice < DISPLAY_INITIAL_STATUS_ALL_WAREHOUSES || choice > EXIT_CHOICE)//While the user provides us with invalid input, we want to display an error message and have them re-enter their input
            {
                Console.WriteLine("Invalid selection. The user's menu selection for the operations should be {0} to {}", DISPLAY_INITIAL_STATUS_ALL_WAREHOUSES, EXIT_CHOICE);
                Console.WriteLine("\nPlease entering an option from the menu above ");//display an error message if the user gave us invalid input
                choice = readInt();//read in the user's input for the menu selection
            }//once this point in the code is reached, we are guaranteed that the user has entered a valid selection from the menu

            return choice;
        }

        
        /**
        * This function readInt is used for reading input value.
        * 
        * @return The valid integer number
        */
        public static int readInt()
        {
            bool error = false;
            string value = "";
            int intResult = 0;
            do
            {
                try
                {

                    // enter here.
                    Console.Write("Please enter a integer value according to menu option: ");
                    value = Console.ReadLine();
                    intResult = Convert.ToInt32(value);
                    
                    error = false;
                    
                }
                catch (FormatException)
                {
                    // accept integer only.
                    Console.WriteLine("The {0} is Invalid Input..Please Input Integer Only..",value);
                    error = true;
                }
            } while (error);

            return intResult;
        }

        /**
         * This method check condition to excute the third option
         */
        public static bool checkConditionToExcuteDisplayListTransaction()
        {
            bool satify = false;
            if (inventory.WareHouseList.Count == 0)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("<Warning> All warehouses is empty. "
                        + "Therefore, this function cannot processed.");
                Console.WriteLine("<Warning> Before use this option, the user must do initial status for all warehouses. ");
                Console.ForegroundColor = ConsoleColor.Black;
            }
            else
            {
                satify = true;
                
            }

            return satify;
        }

        /**
         * This method check condition to excute the fourth option 
         */
        public static bool checkConditionToExcuteFinalStatusAllWareHouse()
        {
            bool satify = false;
            if (checkConditionToExcuteDisplayListTransaction())
            {
                if (inventory.TransactionItemList.Count == 0)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("<Warning> Before use this option, the user must create initial status for all warehouse and process all transactions from Transactions.txt. ");

                    Console.WriteLine("<Warning> Transactions file is still not read that causes transaction list are empty. "
                            + "Therefore, this function cannot processed.");
                    Console.ForegroundColor = ConsoleColor.Black;
                }
                else
                {
                    satify = true;
                }
            }
            
            return satify;
        }

        /**
         * this method display the initial (beginning of day) status of all warehouse
         */
        private static void displayTheInitialStatusAllWareHouse()
        {
            /**
            * 1. Display the initial (beginning of day) status of all warehouse
            *   =====================================================
            *   The Atlanta warehouse
            *      Item     Quantity
            *      102       500
            *      215       120
            *      410       60
            *      525       0
            *      711       350
            *      
            *    show the same format to each of warehouse
            *        
            */
            inventory = null;//delete the object before use
            inventory = new Inventory();
            inventory.readInventoryTxtFile("Inventory.txt");
            Console.WriteLine("\nDisplay the initial (beginning of day) status of all warehouse");
            Console.WriteLine("================================================================");
            Console.WriteLine(inventory);
        }

        /**
         * this method display the transactions from text file
         */
        private static void displayTheTransactionsTextFile()
        {
            /**
            * Display the list of transaction item from Transactions.txt
            */
            inventory.readTransactionTxtFile("Transactions.txt");
            Console.WriteLine("\nDisplay the status of all transaction from Transactions.txt");
            Console.WriteLine("================================================================");

            Console.WriteLine(inventory.showAllTransaction());
        }
        /**
         * this method process each transaction from the transaction data file and 
         * show which warehouse’s inventory was updated to reflect that transaction.
         */
        private static void processAllTransactionAndShowTheUpdatedWareHouse()
        {
            /**
            * Process each transaction from the transaction data file and show which
            * warehouse’s inventory was updated to reflect that transaction.
            */
            foreach (var transactionItem in inventory.TransactionItemList)
            {
                WareHouse beforeUpdatedWareHouse;
                WareHouse afterUpdatedWareHouse = inventory.searchAndUpdateWareHouseSatifiedSupplyOfItem(transactionItem, out beforeUpdatedWareHouse);
                processShowTheUpdatedWareHouse(transactionItem, beforeUpdatedWareHouse, afterUpdatedWareHouse);

            }
        }

        /**
         * this method show which warehouse’s inventory was updated to reflect that transaction.
         * 
         */
        private static void processShowTheUpdatedWareHouse(TransactionItem transactionItem, WareHouse beforeUpdatedWareHouse, WareHouse afterUpdatedWareHouse)
        {
                        
            Console.WriteLine("\nDisplay the status of warehouse that was updated to reflect that transaction");
            Console.WriteLine("================================================================");
            Console.WriteLine("\tTransaction Code" + "\tItem Number" + "\tQuantity\n");

            Console.WriteLine(transactionItem);
            Console.Write("<Before updated> ");

            Console.WriteLine(beforeUpdatedWareHouse);
            Console.Write("<After updated>  ");
            Console.WriteLine(afterUpdatedWareHouse);
            
        }


        /**
         * this method display the final (ending of day) status of all warehouse
         */
        private static void displayTheFinalStatusAllWareHouse()
        {
            
            /**
            * Display the final (end-of-day) status for all warehouses.
            */
            Console.WriteLine("\nDisplay the final (end of day) status of all warehouse");
            Console.WriteLine("================================================================");
            Console.WriteLine(inventory);
           
        }
        /**
        * Method :processUserOption
        *  This method will do the options of inventory management system menu
        * 
        *  @param choice  The user choice
        * 
        */
        public static void processUserOption(int choice)
        {

            //if (choice == RUN_ALL_STEP)
            //{
            //    //runAllStep();//implementing for extend in the future
            //}
            //else

            if (choice == DISPLAY_INITIAL_STATUS_ALL_WAREHOUSES)
            {
                displayTheInitialStatusAllWareHouse();

            }
            else if (choice == DISPLAY_LIST_TRANSACTION_FROM_TXT_FILE)
            {
                /**
                 * if inventory is empty then require user must use option 1
                 */
                if (checkConditionToExcuteDisplayListTransaction())
                {
                    displayTheTransactionsTextFile();
                    processAllTransactionAndShowTheUpdatedWareHouse();
                    //After run option 3, update variable finalStatusAllWareHouse

                }

            }
            
            else if (choice == DISPLAY_FINAL_STATUS_ALL_WAREHOUSES)
            {
                /**
                 * if inventory is empty then require user must use option 1 or (2 and 3)
                 * otherwise, let user see the final status of warehouses.
                 */
                if (checkConditionToExcuteFinalStatusAllWareHouse())
                {
                    displayTheFinalStatusAllWareHouse();
                }
                    
            }
            else if (choice == EXIT_CHOICE)
            {
                Console.WriteLine("<Option> EXIT_CHOICE");
            }

        }
        

    }
}