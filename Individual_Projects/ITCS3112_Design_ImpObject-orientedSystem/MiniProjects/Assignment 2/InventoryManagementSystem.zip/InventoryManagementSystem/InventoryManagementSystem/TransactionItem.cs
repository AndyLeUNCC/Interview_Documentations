﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace InventoryManagementSystem
{
    /**
     * 
     * Class Name : DemoCraps
     * Student Name: Andy Le
     * Date: May 30, 2020
     * Description: This class represent a transaction item that extend from item class
     * 
     */
    public class TransactionItem:Item
    {
        private string transactionCode;// 'P': purchase, 'S':sale

        

        public string TransactionCode { get => transactionCode; set => transactionCode = value; }

        /**
         * non-argument constructor
         */
        public TransactionItem() : base()
        {
            transactionCode = "";

        }
        /**
         * constructor with parameter
         */
        public TransactionItem(string transactionCode, string identifiedNumber, string quantity) : base (identifiedNumber,quantity)
        {
            this.transactionCode = transactionCode;
            
        }

        /**
         * This method will parse a list of string that contain information of a transaction into a transaction item object
         */
        public TransactionItem parseDataIntoTransactionItem(List<string> record)
        {
           
            TransactionItem transactionItem = new TransactionItem(record[0], record[1] , record[2]);

            return transactionItem;
        }

        /**
         * toString method to show the status of transaction item object
         */
        public override string ToString()
        {
            /**
            * Display the  status of a transaction item
            *   =====================================================
            *      
            *      Transaction Code     Item Number     Quantity
            *         P                 410             1000
            *         
            *        
            */
            String status = "";
            
            
            status += "\t\t" + transactionCode + "\t\t" + IdentifiedNumber + "\t\t" + Quantity + "\n";
            

            return status;
        }
    }
}
