﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace InventoryManagementSystem
{
    /**
     * 
     * Class Name : TxtFileUtility
     * Student Name: Andy Le
     * Date: May 30, 2020
     * Description: This class will process a text file with basic functions.
     * For example, read content file and parse a line string into a list of string
     * 
     */
    public class TxtFileUtility
    {
        private string pathFile;//hold the path of current dictory 
        private List<String> fileContent;//hold the file content as a string collection
        private string delimeter = ",";//hold the delimeter

        /**
         * non-argument constructor
         */
        public TxtFileUtility()
        {
            
            fileContent = new List<string>() ;

        }


        public List<string> FileContent { get => fileContent; set => fileContent = value; }

        /**
         * split each element in each line and
         * trim space between each field
         */
        public List<string> splitRecordIntoField(string line)
        {
            List<string> fields = line.Split(delimeter).ToList();
            List<string> trimFields = new List<string>();
            foreach(string field in fields)
            {
                trimFields.Add(field.Trim());
            }
        
            return trimFields;
        }
        /**
         * This method read a text file with a file name provided
         */
        public List<string> readTextFile(string fileName)
        {
            string line;//a line in the text file

            try
            {

                //Pass the file path and file name to the StreamReader constructor
                pathFile = Path.Combine(Directory.GetCurrentDirectory(), "" + fileName);
                StreamReader sr = new StreamReader(pathFile);

                //Read the first line of text
                line = sr.ReadLine();

                //Continue to read until you reach end of file
                while (line != null)
                {
                    //write the lie to console window
                    //Console.WriteLine(line);
                    fileContent.Add(line);
                    //Read the next line
                    line = sr.ReadLine();
                }

                //close the file
                sr.Close();

            }
            catch (Exception e)
            {
                Console.WriteLine("Exception: " + e.Message);
            }
            finally
            {
                
                Console.WriteLine("<Successful> Reading file " + fileName);
                
            }
            return fileContent;
        }
       
                
        
    }
}
