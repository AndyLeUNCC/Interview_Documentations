using Microsoft.VisualStudio.TestTools.UnitTesting;
using CateringForm;
using System;

namespace CateringFormTests
{
    [TestClass]
    public class CateringTests
    {
        
        public CateringTests()
        {
            FileUtility.deleteFileIfExists("entrees.txt");
            FileUtility.deleteFileIfExists("dishes.txt");
            FileUtility.deleteFileIfExists("desserts.txt");


            Catering initCatering = new Catering();
            initCatering.initialData();

            initCatering.createDataTextFiles();
        }
        [TestMethod]
        public void testInputDataInvalid_NumberOfGuestIsNotNumeric()
        {
            //Arrange
            Catering catering = new Catering();
            catering.readDataFromTextFiles();
            double costOfEventExpected = 0.0;

            catering.Customer.CustomerName = "UNCC";
            catering.Customer.PhoneNumber = "080-134-xxxx";
            catering.NumberOfGuests = " 50a ";
            catering.ChosenEntree = new Entree(catering.EntreeList[2].Name);//French
            catering.ChosenDessert = new Dessert(catering.DessertList[0].Name);
            catering.ChosenDishList.Insert(0, catering.DishList[0]);
            catering.ChosenDishList.Insert(1, catering.DishList[1]);


            //Act
            double costOfEventActual = catering.calculateCostOfTheEvent();

            //Assert

            Assert.AreEqual(costOfEventExpected, costOfEventActual);
        }

        [TestMethod]
        public void testInputDataInvalid_ChosenMoreThanTwoDishes()
        {
            //Arrange
            Catering catering = new Catering();
            catering.readDataFromTextFiles();
            //double costOfEventExpected = 2.0;

            //create data for customer 1
            catering.Customer.CustomerName = "Andy";
            catering.Customer.PhoneNumber = "740-134-1111";
            catering.NumberOfGuests = " 50 ";
            catering.ChosenEntree = new Entree(catering.EntreeList[2].Name);//French
            catering.ChosenDessert = new Dessert(catering.DessertList[0].Name);
            catering.ChosenDishList.Insert(0, catering.DishList[0]);
            catering.ChosenDishList.Insert(1, catering.DishList[1]);


            catering.ChosenDishList.Add(new Dish("abc"));//test error
            //Act
            double costOfEventActual = catering.calculateCostOfTheEvent();

            //Assert
            Assert.AreEqual(0, catering.ChosenDishList.Count);

            //Assert.AreEqual(costOfEventExpected, costOfEventActual, "<Error> chosen more than two dishes");

        }
        [TestMethod]
        public void testInputDataValid_OutputResultsToEventTextFile()
        {
            //Arrange
            Catering catering = new Catering();
            catering.readDataFromTextFiles();
            double costOfEventExpected = Catering.COST_OF_ONE_CUSTOMER * 50;

            //create data for customer 1
            catering.Customer.CustomerName = "Andy";
            catering.Customer.PhoneNumber = "740-134-1111";
            catering.NumberOfGuests = " 50 ";
            catering.ChosenEntree = new Entree(catering.EntreeList[2].Name);//French
            catering.ChosenDessert = new Dessert(catering.DessertList[0].Name);
            bool checkBox1 = false;
            bool checkBox2 = false;
            bool checkBox3 = false;
            bool checkBox4 = false;
            //int countDishes = 0;
            if (checkBox1) {
                
                catering.ChosenDishList.Add(catering.DishList[0]);
            }
            if (checkBox2)
            {
                catering.ChosenDishList.Add(catering.DishList[1]);

            }
            if (checkBox3)
            {
                catering.ChosenDishList.Add(catering.DishList[2]);

            }
            if (checkBox4)
            {
                catering.ChosenDishList.Add(catering.DishList[3]);

            }

            //Act
            double costOfEventActual = catering.calculateCostOfTheEvent();

            Assert.AreEqual(costOfEventExpected, costOfEventActual);

            if (costOfEventActual > 0)
            {
                //no element in list of chosen dishes
                if (catering.ChosenDishList.Count < Catering.CHOSEN_DISH_LIST_NUMBER_THRESHOLD)
                {
                    for (int i = 1; i <= Catering.CHOSEN_DISH_LIST_NUMBER_THRESHOLD; i++ )
                        catering.ChosenDishList.Add(new Dish());

                }
                FileUtility.writeTextFile(catering.ToString(), "Event.txt"); ;
                Console.WriteLine("Data was written into Event.txt successful");
            }

        }

        [TestMethod]
        public void testInputDataInValid_NumberOfGuestsIsEmpty()
        {
            //Arrange
            Catering catering = new Catering();
            catering.readDataFromTextFiles();
            double costOfEventExpected = 0;

            //create data for customer 1
            catering.Customer.CustomerName = "Andy";
            catering.Customer.PhoneNumber = "740-134-1111";
            catering.NumberOfGuests = " ";
            catering.ChosenEntree = new Entree(catering.EntreeList[2].Name);//French
            catering.ChosenDessert = new Dessert(catering.DessertList[0].Name);
            catering.ChosenDishList.Insert(0,catering.DishList[1]);
            catering.ChosenDishList.Insert(1,catering.DishList[2]);

            //Act
            double costOfEventActual = catering.calculateCostOfTheEvent();

            Assert.AreEqual(costOfEventExpected, costOfEventActual);
              
        }

        [TestMethod]
        public void testInputDataValid_OutputResultsContainNullToEventTextFile()
        {
            //Arrange
            Catering catering = new Catering();
            catering.readDataFromTextFiles();
            double costOfEventExpected = Catering.COST_OF_ONE_CUSTOMER * 6;

            //create data for customer 1
            catering.Customer.CustomerName = "Andy";
            catering.Customer.PhoneNumber = "740-134-1111";
            catering.NumberOfGuests = " 6 ";
            
            //Act
            double costOfEventActual = catering.calculateCostOfTheEvent();

            Assert.AreEqual(costOfEventExpected, costOfEventActual);

            if (costOfEventActual > 0)
            {
                FileUtility.writeTextFile(catering.ToString(), "Event.txt"); ;
                Console.WriteLine("Data was written into Event.txt successful");
            }

        }
    }
}
