﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace CateringForm
{
    /**
    * 
    * Class Name : FileUtility
    * Student Name: Andy Le
    * Date: June 9, 2020
    * Description: This class will represent a event's information of catering.
    * 
    * 
    */
    public class Catering
    {
        public const double COST_OF_ONE_CUSTOMER = 35;
        public const int CHOSEN_DISH_LIST_NUMBER_THRESHOLD = 2;
        private List<Entree> entreeList;//hold the list of entree
        private List<Dish> dishList;//hold the list of dish
        private List<Dessert> dessertList;//hold the list of dessert
        FileUtility fileUtility;


        /**
         * hold information of a event of an catering
         */
        private Customer customer;
        private string numberOfGuests;
        private Entree chosenEntree;//the chosen entree
        private Dessert chosenDessert;//the chosen dessert
        private List<Dish> chosenDishList;
        private double costOfTheEvent;



        public Entree ChosenEntree { get => chosenEntree; set => chosenEntree = value; }
        public Dessert ChosenDessert { get => chosenDessert; set => chosenDessert = value; }
        public List<Dish> ChosenDishList { get => chosenDishList; set => chosenDishList = value; }
        public List<Entree> EntreeList { get => entreeList; set => entreeList = value; }
        public List<Dish> DishList { get => dishList; set => dishList = value; }
        public List<Dessert> DessertList { get => dessertList; set => dessertList = value; }
        public Customer Customer { get => customer; set => customer = value; }
        public string NumberOfGuests { get => numberOfGuests; set => numberOfGuests = value; }
        public FileUtility FileUtility { get => fileUtility; set => fileUtility = value; }
        public double CostOfTheEvent { get => costOfTheEvent; set => costOfTheEvent = value; }

        public Catering()
        {
            entreeList = new List<Entree>();
            dishList = new List<Dish>();
            dessertList = new List<Dessert>();
            customer = new Customer();

            numberOfGuests = "none";
            costOfTheEvent = 0.0;
            chosenEntree = new Entree();
            chosenDessert = new Dessert();
            chosenDishList = new List<Dish>();
            fileUtility = new FileUtility();
            
        }

        /**
         * prepare data to run for testing 
         * set some value to run
         */
        public void initialData()
        {
            entreeList.Add(new Entree("American"));
            entreeList.Add(new Entree("Canadian"));
            entreeList.Add(new Entree("French"));
            entreeList.Add(new Entree("Mexican"));
            entreeList.Add(new Entree("Vietnamese"));

            dishList.Add(new Dish("Baked Pork"));
            dishList.Add(new Dish("Garlic Chicken"));
            dishList.Add(new Dish("Maple Salmon"));
            dishList.Add(new Dish("Grilled Chicken"));

            dessertList.Add(new Dessert("Pizza Cake"));
            dessertList.Add(new Dessert("Egg Cake"));
            dessertList.Add(new Dessert("Chocolate Cake"));
            
        }

        
        /**
         */
        public void readDataFromTextFiles()
        {
            //bool errorReadDataFromTextFiles = false;
            if (!readDataFromTextFileIntoListOfItem())
            {
                //not error after read data from text files into lists of item.
                //load data into controls in GUI of CateringForm

                Console.WriteLine("<Successfull> Load data from text files into lists of item.");
            }
            else
            {
                //using data
                initialData();
                Console.WriteLine("<Successfull> Load data from coding into lists of item.");

            }

            //return errorReadDataFromTextFiles;
        }
        /**
         * if there is error while creating data from text files,
         * program will read data from the assigned data inside programm
         */
        public bool createDataTextFiles()
        {
            bool errorCreateDataFromTextFiles = false;
            string fileName = "entrees.txt";
            foreach(Entree item in EntreeList)
            {
                FileUtility.writeTextFile(item.Name, fileName);

            }
            fileName = "dishes.txt";
            foreach (Dish item in dishList)
            {
                FileUtility.writeTextFile(item.Name, fileName);

            }
            fileName = "desserts.txt";
            foreach (Dessert item in dessertList)
            {
                FileUtility.writeTextFile(item.Name, fileName);

            }

            return errorCreateDataFromTextFiles;

        }
        /**
         * errorCode = 1: number of guest is not numeric
         * errorCode = 2 : wrong with only two dishes can be selected
         * errorCode = 3 : number of guests is empty
         */

        public int validateInputData()
        {
            int errorCode = 0;

            if (Regex.IsMatch(NumberOfGuests, @"[a-zA-Z]"))
            {
                errorCode = 1;
            }
            else if (ChosenDishList.Count > 2)
            {
                /**
                 * Check if only two or less dishes are selected
                 */
                
                errorCode = 2;
            } else if (NumberOfGuests.Trim() == "")
            {
                //number of guests is empty
                errorCode = 3;
            }




            return errorCode;
        }

        /**
         * calculate the cost of the event
         */
        public double calculateCostOfTheEvent()
        {
            int errorCode = 0;
            errorCode = validateInputData();
            if (errorCode != 0)
            {
                if (errorCode == 1)
                {
                    costOfTheEvent = 0.0;
                    Console.WriteLine("<Error> Cost of the event is 0 because the entered value for the number of guests is not numeric.");
                } else if(errorCode == 2)
                {
                    //remove all the current side dish selections so that the user can start over
                    chosenDishList.Clear();
                    Console.WriteLine("<Error> Only one or up to two dishes can be chosen.");
                } else if (errorCode == 3)
                {
                    //number of guests is not entered
                    costOfTheEvent = 0.0;
                    Console.WriteLine("<Error> The entered value for the number of guests is empty.");
                }
                
            }
            else
            {
                NumberOfGuests = NumberOfGuests.Trim();
                int numberOfGuest = Int32.Parse(NumberOfGuests);
                costOfTheEvent = numberOfGuest * COST_OF_ONE_CUSTOMER;
            }
            return costOfTheEvent;
        }

        /**
         * init data for the window form
         * read data from some files, such as dishes.txt, desserts.txt, entrees.txt
         * and load data into some list when the form load
         */
        public bool readDataFromTextFileIntoListOfItem()
        {
            bool error = false;

            List<String> fileContent;
            fileContent = fileUtility.readTextFile("entrees.txt");
            //parse data into list of entree
            foreach(string item in fileContent)
            {
                entreeList.Add(new Entree(item));
            }
            fileContent.Clear();
            fileContent = fileUtility.readTextFile("dishes.txt");
            //parse data into list of dishes
            foreach (string item in fileContent)
            {
                dishList.Add(new Dish(item));
            }
            fileContent.Clear();
            fileContent = fileUtility.readTextFile("desserts.txt");
            //parse data into list of desserts
            foreach (string item in fileContent)
            {
                dessertList.Add(new Dessert(item));
            }

            if (entreeList.Count == 0 || dishList.Count == 0 || dessertList.Count == 0)
            {
                error = true;
            }
            return error;

        }
       
        /**
         * toString method to show the status of catering object
         */
        public override string ToString()
        {
            //Andy 74 - 134 - 1111  50  none Baked Pork Maple Salmon Chocolate Cake $1750

            string status = "";
            status = "\"" + customer.CustomerName + "\"" + fileUtility.Delimeter
                + "\"" + customer.PhoneNumber + "\"" + fileUtility.Delimeter
                + "\"" + numberOfGuests + "\"" + fileUtility.Delimeter
                + "\"" + chosenEntree.Name + "\"" + fileUtility.Delimeter;
            foreach (Dish item in chosenDishList)
            {
                status += "\"" + item.Name + "\"" + fileUtility.Delimeter;
            }
            status += "\"" + chosenDessert.Name + "\"" + fileUtility.Delimeter + "\"" + "$" + costOfTheEvent+ "\"";

            return status;
        }


    }
}
