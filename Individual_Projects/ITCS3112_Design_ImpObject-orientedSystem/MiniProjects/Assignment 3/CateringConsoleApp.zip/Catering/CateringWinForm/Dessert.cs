﻿namespace CateringForm
{
    /**
    * 
    * Class Name : FileUtility
    * Student Name: Andy Le
    * Date: June 9, 2020
    * Description: This class will represent a dessert.
    * 
    * 
    */
    public class Dessert:Food
    {
        public Dessert() : base()
        {
        }
        public Dessert(string name) : base(name)
        {
        }
    }
}