﻿namespace CateringForm
{
    /**
    * 
    * Class Name : FileUtility
    * Student Name: Andy Le
    * Date: June 9, 2020
    * Description: This class will represent a dish.
    * 
    * 
    */
    public class Dish:Food
    {
        public Dish() : base()
        {
        }
        public Dish(string name) : base(name)
        {
        }
    }
}