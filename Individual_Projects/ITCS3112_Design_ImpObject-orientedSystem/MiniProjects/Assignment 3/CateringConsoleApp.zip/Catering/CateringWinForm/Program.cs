﻿using System;

namespace CateringForm
{
    class Program
    {
        static void MainProgram(string[] args)
        {
            Console.WriteLine("Hello World!");
            /**
             * 
             * Reference 
             * https://www.chegg.com/homework-help/questions-and-answers/objective-objective-assignment-write-visual-c-gui-app-using-check-boxes-combo-boxes-window-q30517218
             * 
             * INSTRUCTIONS:
                Cindy’s catering provides meals for parties and special events. Create an
                interactive GUI app that allows Cindy's Catering to better operate their business. The following data must be entered
                concerning the customer and the event:
                 The customer’s name must be entered into a text field.
                 The customer’s contact phone number into a text field.
                 The number of guests invited to a Cindy catered event into a text field.
                 The customer must choose one entrée from a group of at least four choices.
                 The customer must choose up to two side dishes from a group of at least four choices.
                 The customer must choose one desert from a group of at least three choices.

            Solutions:
              create a window form contains the following information:
                   customer's name: textfield
                   customer's contact phone number: text field
                   number of guest invited to a cindy catered event : text field
                   The customer must choose an entree (main course from a meal) from a group of at least four choices
                   ->create a selection box with at least four choices ( at least 4 main courses of meal)
                   The customer must choose up to two side dishes from a group of at least four choices
                    -> componet let user choose one or two item from a group of at least four choices
                   The customer must choose one desert from a group of at least three choices.
                   -> create a selection box with at least three choices.


              =>create classes Customer, Event, Entree, Dish, Dessert
              class Event is a container include some classes: Customer, List of Entree, List of Dish,  List of Dessert
              class Customer has a structure:
                 properties:
                    customerName : string
                    customerContactPhoneNumber: string
                    




            The programmer can make the choices as s(he) desires.
                Display the cost of the event that is calculated as $35 per person.
                ->show message that contains the infor of cost after calculation cost of person
                  $35 * number of person that attend in a event.
               

                To validate the input data, do the following:
                 If the value entered for the number of guest is not numeric, set the event price to zero.
                =>create function check numberic
                =>set the event price to zero
                 If the user attempts to choose more than two side dishes, remove all the current side dish selections so that the
                user can start over.


                After the final price for the dinner has been calculated, the event information must be saved to an output file so that
                Cindy’s Catering will have the information for the event. The items should be separated by spaces. If any item is not
                chosen, enter the word “none” for that item. The following fields must be written to the output file:
                 the customer’s name
                 the customer’s contact phone number
                 the number of guests
                 the one entrée chosen
                 the two sides chosen
                 the one desert chosen
                Requirements:
                 The data input must be done as a GUI using Windows Forms.
                 The class should be named Catering.
                 The output file should be named Event

             => use the FileUtility write method
             */
        }
    }
}
