﻿using System;
using System.Collections.Generic;
using System.IO;

namespace CateringForm
{
    /**
    * 
    * Class Name : FileUtility
    * Student Name: Andy Le
    * Date: June 9, 2020
    * Description: This class will process a text file with basic functions.
    * For example, read and write file and parse a line string into a list of string
    * 
    */
    public class FileUtility
    {


        private string workingDirectory;//hold the path of working directory
        private List<String> fileContent;//hold the file content as a string collection
        private string delimeter = " ";//hold the delimeter

        public List<string> FileContent { get => fileContent; set => fileContent = value; }
        public string WorkingDirectory { get => workingDirectory; set => workingDirectory = value; }
        public string Delimeter { get => delimeter; set => delimeter = value; }

        /**
         * non-argument constructor
         */
        public FileUtility()
        {
            workingDirectory = Directory.GetCurrentDirectory();
            fileContent = new List<string>();

        }

        /**
         * This method read a text file with a file name provided
         */
        public List<string> readTextFile(string fileName)
        {
            string line;//a line in the text file

            try
            {

                //Pass the file path and file name to the StreamReader constructor
                string pathFile = Path.Combine(Directory.GetCurrentDirectory(), fileName); ;
                StreamReader sr = new StreamReader(pathFile);

                //Read the first line of text
                line = sr.ReadLine();

                //Continue to read until you reach end of file
                while (line != null)
                {
                    //write the lie to console window
                    //Console.WriteLine(line);
                    fileContent.Add(line.Trim());
                    //Read the next line
                    line = sr.ReadLine();
                }

                //close the file
                sr.Close();
                Console.WriteLine("<Successful> Reading file " + fileName);
            }
            catch (Exception e)
            {
                Console.WriteLine("Exception: " + e.Message);
            }

            return fileContent;
        }

        /**
         * This method show content of a text file with a file name provided
         */
        public void showTextFile(string fileName)
        {
            string line;//a line in the text file

            try
            {
                Console.WriteLine("<Starting> Show content of file " + fileName);
                //Pass the file path and file name to the StreamReader constructor
                string pathFile = Path.Combine(Directory.GetCurrentDirectory(), fileName); ;
                StreamReader sr = new StreamReader(pathFile);

                //Read the first line of text
                line = sr.ReadLine();

                //Continue to read until you reach end of file
                while (line != null)
                {
                    //write the lie to console window
                    Console.WriteLine(line);
                    //Read the next line
                    line = sr.ReadLine();
                }

                //close the file
                sr.Close();
                Console.WriteLine("<Ending> Show content of file " + fileName);
            }
            catch (Exception e)
            {
                Console.WriteLine("Exception: " + e.Message);
            }

        }

        /**
         * This method write content in a text file with a file name provided
         */
        public static void writeTextFile(string line, string fileName)
        {
            try
            {
                string pathFile = Path.Combine(Directory.GetCurrentDirectory(), fileName); ;

                //Pass the file path and file name to the StreamWriter constructor
                StreamWriter sw = File.AppendText(pathFile);

                //Write a line of text
                sw.WriteLine(line);

                //Close the file
                sw.Close();
            }
            catch (Exception e)
            {
                Console.WriteLine("Exception: " + e.Message);
            }

        }


        /**
         * This method will delete file if it exists
         */
        public static void deleteFileIfExists(string fileName)
        {

            try
            {
                string pathFile = Path.Combine(Directory.GetCurrentDirectory(), fileName); ;

                // Check if file exists with its full path    
                if (File.Exists(pathFile))
                {
                    // If file found, delete it    
                    File.Delete(pathFile);
                }
                //else Console.WriteLine("File {0} not found to delete", filePath);
            }
            catch (IOException ioExp)
            {
                Console.WriteLine(ioExp.Message);
            }
        }
    }
}
