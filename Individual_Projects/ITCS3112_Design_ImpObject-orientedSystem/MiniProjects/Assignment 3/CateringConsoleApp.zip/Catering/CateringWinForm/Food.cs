﻿using System;
namespace CateringForm
{
    /**
    * 
    * Class Name : FileUtility
    * Student Name: Andy Le
    * Date: June 9, 2020
    * Description: This class will represent a abstraction food.
    * 
    * 
    */
    public class Food
    {
        private string name;

        
        public Food()
        {
            this.name = "none";
        }

        public Food(string name)
        {
            this.name = name;
        }

        public string Name { get => name; set => name = value; }

        
    }
}
