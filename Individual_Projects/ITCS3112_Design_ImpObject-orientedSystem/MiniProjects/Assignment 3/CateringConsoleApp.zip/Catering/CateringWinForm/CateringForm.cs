﻿using System;
namespace CateringForm
{
    public class CateringForm
    {
        private static Catering catering = new Catering();

        public static void Main(string[] args)
        {
            Console.WriteLine("CateringWinform.cs called");
        }
        public void testCustomer1()
        {
            /**
            * create initial text files.
            * 
            */

            //catering.initialData();//for the first time run program
            //catering.createDataTextFiles();


            /**Todo
             * write the method to update data of lists into the controls of GUI
             */


            /**
             * init data for test such as customer's infor, number of guest, ...
             */
            //catering.createDataOfCustomer1();

            /**
             * after user have already data load into the controls of GUI
             * and user inputted the customer's information
             * , number of guests and chose the options such as entree, dishes, dessert
             * ,program will calculate the cost of event and output nessary infor to Even.txt
             */

            if (catering.calculateCostOfTheEvent() > 0)
            {
                FileUtility.writeTextFile(catering.ToString(), "Event.txt"); ;
                Console.WriteLine("Data was written into Event.txt successful");
            }
        }
       

        public CateringForm()
        {
            catering.readDataFromTextFiles();

        }
    }
}
