﻿using System;
namespace CateringForm
{
    /**
    * 
    * Class Name : FileUtility
    * Student Name: Andy Le
    * Date: June 9, 2020
    * Description: This class will represent a entree.
    * 
    * 
    */
    public class Entree:Food
    {
        public Entree():base()
        {
        }
        public Entree(string name) : base(name)
        {
        }
    }
}
