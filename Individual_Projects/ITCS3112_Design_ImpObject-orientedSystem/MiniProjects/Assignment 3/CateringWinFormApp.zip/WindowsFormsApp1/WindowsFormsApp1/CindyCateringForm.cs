﻿using System;
using System.CodeDom;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using CateringForm;

namespace WindowsFormsApp1
{
    public partial class CindyCateringFrm : Form
    {
        public CindyCateringFrm()
        {
            InitializeComponent();
        }

        private void CindyCateringFrm_Load(object sender, EventArgs e)
        {
            FileUtility.deleteFileIfExists("entrees.txt");
            FileUtility.deleteFileIfExists("desserts.txt");


            Catering initCatering = new Catering();
            initCatering.initialData();

            initCatering.createDataTextFiles();
            foreach(Entree item in initCatering.EntreeList)
            {
                cboEntree.Items.Add(item.Name);
            }
            foreach (Dessert item in initCatering.DessertList)
            {
                cboDessert.Items.Add(item.Name);
            }
            


        }

        /**
         * This method will validate input data from control of GUI 
         * and return a string that contains the error message to user.
         */
        private string validateInputData()
        {
            string errorMessage = "";
            if (string.IsNullOrEmpty(txtCustomerName.Text)){
                errorMessage += "The customer's name must be entered into a customer name text field.\n";

            }

            if (string.IsNullOrEmpty(txtNumberOfGuests.Text.Trim()))
            {
                errorMessage += "The number of guests must be entered into a number of guests text field.\n";

            } else 
            {
                try
                {
                    int numberOfGuest = Int32.Parse(txtNumberOfGuests.Text);

                }
                catch (FormatException)
                {
                    errorMessage += "The entered value for the number of guests is not numeric.\n";

                }


            }

            if ((cboEntree.SelectedItem == null)){
                errorMessage += "The customer must choose one entree from a group of entrees.\n";

            }

            int countDishes = 0;
            if (ckbBakedPork.Checked)
            {
                countDishes++;
            }
            if (ckbMapleSalmon.Checked)
            {
                countDishes++;

            }
            if (ckbGarlicChicken.Checked)
            {
                countDishes++;

            }
            if (ckbGrilledChicken.Checked)
            {
                countDishes++;

            }

            if (countDishes > 2)
            {
                ckbBakedPork.Checked = false;
                ckbMapleSalmon.Checked = false;
                ckbGrilledChicken.Checked = false;
                ckbGarlicChicken.Checked = false;
                errorMessage += "Only one or up to two dishes can be chosen.\n";
            }



            if (cboDessert.SelectedItem == null){
                errorMessage += "The customer must choose one desert from a group of desserts.\n";

            }
            
            return errorMessage;
        }

        /**
         * This method will calculate the cost of event
         */

        private void calculateCostOfEvent()
        {
            //Arrange
            Catering catering = new Catering();
            catering.readDataFromTextFiles();

            //create data for customer 1
            catering.Customer.CustomerName = txtCustomerName.Text.Trim();
            if (string.IsNullOrEmpty(txtPhoneNumber.Text.Trim()))
            {
                catering.Customer.PhoneNumber = "none";
            }
            else
            {
                catering.Customer.PhoneNumber = txtPhoneNumber.Text.Trim();
            }
            catering.NumberOfGuests = txtNumberOfGuests.Text;

            catering.ChosenEntree = new Entree(cboEntree.SelectedItem.ToString());
            catering.ChosenDessert = new Dessert(cboDessert.SelectedItem.ToString());

            catering.ChosenDishList.Clear();
            if (ckbBakedPork.Checked)
            {
                catering.ChosenDishList.Add(new Dish("Baked Pork"));
            }
            if (ckbGarlicChicken.Checked)
            {
                catering.ChosenDishList.Add(new Dish("Garlic Chicken"));

            }
            if (ckbMapleSalmon.Checked)
            {
                catering.ChosenDishList.Add(new Dish("Maple Salmon"));

            }
            if (ckbGrilledChicken.Checked)
            {
                catering.ChosenDishList.Add(new Dish("Grilled Chicken"));

            }

            //Act
            double costOfEventActual = catering.calculateCostOfTheEvent();

            if (costOfEventActual > 0)
            {
                //no element in list of chosen dishes
                if (catering.ChosenDishList.Count < Catering.CHOSEN_DISH_LIST_NUMBER_THRESHOLD)
                {
                    for (int i = catering.ChosenDishList.Count; i < Catering.CHOSEN_DISH_LIST_NUMBER_THRESHOLD; i++)
                        catering.ChosenDishList.Add(new Dish());

                }
                FileUtility.writeTextFile(catering.ToString(), "Event.txt");
                string message = "The cost of the event that is calculated as $" + Catering.COST_OF_ONE_CUSTOMER + " per person.\n";
                message += "The total cost of the event that customer ordered :$" + costOfEventActual + "\n";
                message += "<Successful> Data was written into Event.txt in path " + FileUtility.workingDirectory;
                MessageBox.Show(message, "Notice Message", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
        }
        private void btnOrderSubmit_Click(object sender, EventArgs e)
        {
            string errorMessage = validateInputData();
            if (!string.IsNullOrEmpty(errorMessage))
            {
                MessageBox.Show(errorMessage,"Error Message",MessageBoxButtons.OK,MessageBoxIcon.Error);
            } else
            {
                calculateCostOfEvent();
            }
            
        }

        private void CindyCateringFrm_Load_1(object sender, EventArgs e)
        {

        }
    }
}
