﻿namespace CateringForm
{
    /**
    * 
    * Class Name : FileUtility
    * Student Name: Andy Le
    * Date: June 9, 2020
    * Description: This class will represent a customer's information.
    * 
    * 
    */
    public class Customer
    {
        private string customerName;
        private string phoneNumber;

        public Customer()
        {
            this.customerName = "none";
            this.phoneNumber = "none";
        }
        public Customer(string customerName, string phoneNumber)
        {
            this.customerName = customerName;
            this.phoneNumber = phoneNumber;
        }

        public string CustomerName { get => customerName; set => customerName = value; }
        public string PhoneNumber { get => phoneNumber; set => phoneNumber = value; }


    }
}